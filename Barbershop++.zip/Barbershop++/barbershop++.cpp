#include <iostream>
#include <mutex>
#include <condition_variable>

// Shop Capacity...
std::mutex m_num_people;
int shop_capacity;

// Sofa Capacity...
std::mutex m_sofa_capacity;
std::condition_variable cv_sofa_not_full;
std::condition_variable cv_sofa_not_empty;
bool sofa_occupied[4];

// Customer waits for sofa...
void cust_waits_for_sofa() {
	std::unique_lock<std::mutex>  lk(m_sofa_capacity);
	cv_sofa_not_full.wait(lk, []{return sofa_capacity > 0;});
	sofa_capacity--;
	cv_sofa_not_empty.notify_one()
}

// Customer gets on sofa...
void cust_get_up_sofa() {
	std::unique_lock<std::mutex> lk(m_sofa_capacity);
	sofa_capacity++;
	cv_sofa_not_full.notify_one();
}


// Barber Ready for Haircut...
std::mutex m_barber_ready_for_haircut;
std::condition_variable cv_barber_ready_for_haircut;
bool barber_readt_for_haircut[3];

// Customer ready for haircut...
std::mutex m_customer_ready_for_haircut;
std::condition_variable cv_m_customer_ready_for_haircut[3];
bool m_customer_ready_for_haircut[3];


// Haircut complete... 
std::mutex m_haircut_complete;
std::condition_variable cv_haircut_complete;
bool haircut_complete[3];

